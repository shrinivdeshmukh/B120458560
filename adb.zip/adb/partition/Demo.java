import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.jdbc.PreparedStatement;


public class Demo {
   
   
    static final String MYDB_URL = "jdbc:mysql://localhost/company";
   
    static final String USER = "root";

    static final String PASSWORD = "root";
   
    public static void main(String[] args){
       
        Scanner sc = new Scanner(System.in);
        float min1,max1,min2,max2,min3;
       
        Connection con = null;
        Statement stmt = null;
        PreparedStatement stmt1;
        try{
           
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Connecting to database");
            con=DriverManager.getConnection(MYDB_URL,USER,PASSWORD);
           
            stmt = con.createStatement();
     
            String sql = "SELECT * from Employee";
            ResultSet rs = stmt.executeQuery(sql);
            System.out.println("*** This is Employee table ***");
            System.out.println(" ");
            while(rs.next())
            {
             System.out.println(rs.getString("id") + "\t" + rs.getString("name") + "\t" + rs.getString("salary"));
            }
            System.out.println(" ");
           
            System.out.println("Please enter the ranges for 3 partitions:  ");
           
            System.out.println("Enter min range value for disk 1 data: ");
            min1 = sc.nextFloat();
            System.out.println("Enter max range value for disk 1 data: ");
            max1 = sc.nextFloat();
           
            System.out.println("Enter max range value for disk 2 data: ");
            max2 = sc.nextFloat();
           
           /*Partition table 1*/
           // sql = "create table if not exists partition1 as select * from Employee where salary >= min1 and salary < max1";
            stmt1 = (PreparedStatement) con.prepareStatement("create table if not exists partition1 as select * from Employee where salary >= ? and salary < ?");
            stmt1.setFloat(1, min1);
            stmt1.setFloat(2, max1);
           
            stmt1.executeUpdate();
            sql = "SELECT * from partition1";
            rs = stmt1.executeQuery(sql);
            System.out.println("*** This is Disk1 data ***");
            System.out.println(" ");
            while(rs.next())
            {
             System.out.println(rs.getString("id") + "\t" + rs.getString("name") + "\t" + rs.getString("salary"));
            }
            System.out.println(" ");
           
            
            /*Partition table 2*/
            stmt1 = (PreparedStatement) con.prepareStatement("create table if not exists partition2 as select * from Employee where salary >= ? and salary < ?");
            stmt1.setFloat(1, max1);
            stmt1.setFloat(2, max2);
           
            stmt1.executeUpdate();
            sql = "SELECT * from partition2";
            rs = stmt1.executeQuery(sql);
            System.out.println("*** This is Disk2 data ***");
            System.out.println(" ");
            while(rs.next())
            {
             System.out.println(rs.getString("id") + "\t" + rs.getString("name") + "\t" + rs.getString("salary"));
            }
            System.out.println(" ");
            
            /*Partition table 3*/
            stmt1 = (PreparedStatement) con.prepareStatement("create table if not exists partition3 as select * from Employee where salary >= ?");
            stmt1.setFloat(1, max2);
            
           
            stmt1.executeUpdate();
            sql = "SELECT * from partition3";
            rs = stmt1.executeQuery(sql);
            System.out.println("*** This is Disk3 data ***");
            System.out.println(" ");
            while(rs.next())
            {
             System.out.println(rs.getString("id") + "\t" + rs.getString("name") + "\t" + rs.getString("salary"));
            }
            System.out.println(" ");
            
           
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
       
       
       
    }
}